<!DOCTYPE html>
<html>
    <?php include('../../../../include/head.php'); ?>
    <body>
      <div><?php include('../../../../include/header.php'); ?></div>
      <div id="content">
      <div><?php include('index-include.php'); ?></div>
      <div><?php include('../../../../include/footer.php'); ?></div>
      </div>
    </body>
</html>